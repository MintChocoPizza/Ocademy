#ifndef __CSCENEGAME__H__
#define __CSCENEGAME__H__

class CSceneGame : public CSceneBase
{


public:
	CSceneGame();
	virtual ~CSceneGame();

	virtual bool Update(void);
};



#endif // !__CSCENEGAME__H__

