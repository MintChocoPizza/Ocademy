#ifndef __CSCENECLEAR_H__
#define __CSCENECLEAR_H__

class CSceneClear : public CSceneBase
{
public:
	CSceneClear();
	virtual ~CSceneClear();

	virtual bool		Update(void);
};

#endif // !__CSCENECLEAR_H__

