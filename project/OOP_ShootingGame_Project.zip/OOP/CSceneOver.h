#ifndef __CSCENEOVER_H__
#define __CSCENEOVER_H__

class CSceneOver : public CSceneBase
{
public:
	CSceneOver();
	virtual	~CSceneOver();

	virtual bool		Update(void);
};


#endif // !__CSCENEOVER_H__

