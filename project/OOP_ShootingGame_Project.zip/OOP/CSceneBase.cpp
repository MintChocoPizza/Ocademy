#include "MyNew.h"
#include "CSceneBase.h"

CSceneBase::CSceneBase()
{
}

CSceneBase::~CSceneBase()
{
}
