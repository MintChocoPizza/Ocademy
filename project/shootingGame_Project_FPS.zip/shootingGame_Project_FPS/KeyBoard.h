#ifndef __KEYBOARD_H__
#define __KEYBOARD_H__

//---------------------------------
// Ű���� �Է�
//---------------------------------
void kb_KeyProcess(void);

void kb_Title(void);
#endif // !__KEYBOARD_H__
